g++ producer.cpp -o producer
g++ consumer.cpp -o consumer
./producer