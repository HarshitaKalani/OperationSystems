g++ server.cpp -o server
./server 5005