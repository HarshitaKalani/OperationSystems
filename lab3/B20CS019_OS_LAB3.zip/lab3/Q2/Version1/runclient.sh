g++ client.cpp -o client
./client 127.0.0.1 5005