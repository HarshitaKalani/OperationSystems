g++ ques2.cpp -o ques2 2>stderr
./ques2 file2 2>stderr 1>stdout