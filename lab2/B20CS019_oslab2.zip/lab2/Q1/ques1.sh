g++ ques1.cpp -o ques1 2>stderr
./ques1 file1 file2 2>stderr 1>stdout