g++ server.cpp -o server
./server c1 c2
